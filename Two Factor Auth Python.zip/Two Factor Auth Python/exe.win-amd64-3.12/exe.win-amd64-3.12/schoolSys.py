import customtkinter
import tkinter as tk
from tkinter import *
from tkinter import messagebox
import database

app=customtkinter.CTk()
app.title('Cyber School')
app.geometry('700x600')     #use x not *   ..owise wont work at all
app.config(bg='firebrick4')
app.resizable(FALSE,FALSE)

font1=('Arial',30,'bold')
font2=('Arial',20,'bold')

def search_course():
    selection=variable3.get()
    if selection != 'Select':
        row=database.search_course(selection)
        id_result_label.configure(text=row[0])
        name_result_label.configure(text=row[1])
        duration_result_label.configure(text=row[2])
        format_result_label.configure(text=row[3])
        language_result_label.configure(text=row[4])
        price_result_label.configure(text=row[5])
    else:
        messagebox.showerror('Error','Select ID')


def insert_ids_options():
    ids=database.fetch_all_ids()
    ids_options.configure(values=ids)
def new_course():
    id_entry.delete(0,END)
    name_entry.delete(0, END)
    variable1.set('1 Week')
    variable2.set('')
    language_entry.delete(0, END)
    price_entry.delete(0, END)

def submit_course():
    id=id_entry.get()
    name=name_entry.get()
    duration=variable1.get()
    format=variable2.get()
    language=language_entry.get()
    price=price_entry.get()

   # try:
    if not (id and name and duration and format and language and price):
            messagebox.showerror('Error','Enter all fields.')
    elif database.id_exists(id):
            messagebox.showerror('Error','ID already exists.')
    else:
            price_value=int(price)
            database.insert_course(id, name, duration, format, language, price_value)
            insert_ids_options()
            messagebox.showinfo('Success', 'Data has been inserted.')

    #except ValueError:
    #messagebox.showerror('Error', 'Price should be an integer.')
    #except:
    #messagebox.showerror('Error', 'Error Occured.')


title_label=customtkinter.CTkLabel(app,font=font1,text='Cyber School Modules:',text_color='SpringGreen2',bg_color='#131314')
title_label.place(x=25,y=20)

frame1=customtkinter.CTkFrame(app,bg_color='green4',fg_color='#292933',corner_radius=10,border_width=2,border_color='gold',width=650,height=230)
frame1.place(x=25,y=70)

frame2=customtkinter.CTkFrame(app,bg_color='green4',fg_color='#292933',corner_radius=10,border_width=2,border_color='gold',width=650,height=200)
frame2.place(x=25,y=350)

id_label=customtkinter.CTkLabel(frame1,font=font2,text='module ID:',text_color='#fff',bg_color='#292933')
id_label.place(x=50,y=15)

id_entry=customtkinter.CTkEntry(frame1,font=font2,text_color='#000',fg_color='#fff',border_color='#B2016C',border_width=2,width=150)
id_entry.place(x=50,y=45)

name_label=customtkinter.CTkLabel(frame1,font=font2,text='module name:',text_color='#fff',bg_color='#292933')
name_label.place(x=245,y=15)

name_entry=customtkinter.CTkEntry(frame1,font=font2,text_color='#000',fg_color='#fff',border_color='#B2016C',border_width=2,width=150)
name_entry.place(x=245,y=45)

duration_label=customtkinter.CTkLabel(frame1,font=font2,text='module duration:',text_color='#fff',bg_color='#292933')
duration_label.place(x=445,y=15)

#duration combobox...in place of textbox

variable1=StringVar()
options=['1 Week','3 Months','6 Months','1 Year']

duration_options = customtkinter.CTkComboBox(frame1,font=font2,text_color='#000',fg_color='#fff',dropdown_hover_color='#B2016C',button_color='#B2016C',button_hover_color='#B2016C',border_color='#B2016C',width=150,variable=variable1,values=options,state='readonly')
duration_options.set('1 Week')
duration_options.place(x=445,y=45)

format_label=customtkinter.CTkLabel(frame1,font=font2,text='module format:',text_color='#fff',bg_color='#292933')
format_label.place(x=40,y=90)

variable2=StringVar()
rb1=customtkinter.CTkRadioButton(frame1,text='Online',fg_color='gold',hover_color='#fff',font=font2,variable=variable2,value='Online')
rb2=customtkinter.CTkRadioButton(frame1,text='Class',fg_color='gold',hover_color='#fff',font=font2,variable=variable2,value='Class')
rb1.place(x=40,y=125)
rb2.place(x=140,y=125)

language_label=customtkinter.CTkLabel(frame1,font=font2,text='module language:',text_color='#fff',bg_color='#292933')
language_label.place(x=245,y=90)

language_entry=customtkinter.CTkEntry(frame1,font=font2,text_color='#000',bg_color='#292933',border_color='#B2016C',border_width=2,width=150)
language_entry.place(x=245,y=120)

price_label=customtkinter.CTkLabel(frame1,font=font2,text='module price:',text_color='#fff',bg_color='#292933')
price_label.place(x=445,y=90)

price_entry=customtkinter.CTkEntry(frame1,font=font2,text_color='#000',fg_color='#fff',border_color='#B2016C',border_width=2,width=150)
price_entry.place(x=445,y=120)

submit_button=customtkinter.CTkButton(frame1,font=font2,text_color='#fff',text='Submit',fg_color='#02ab10',hover_color='#02920D',bg_color='#292933',cursor='hand2',corner_radius=5,width=100,command=submit_course)
submit_button.place(x=200,y=170)

clear_button=customtkinter.CTkButton(frame1,font=font2,text_color='#fff',bg_color='#292933',text='New Entry',fg_color='#F45e02',hover_color='#CB4E01',cursor='hand2',corner_radius=5,width=100,command=new_course)
clear_button.place(x=330,y=170)

search_label=customtkinter.CTkLabel(app,font=font1,text='Search by ID:',text_color='#fff',bg_color='#131314')
search_label.place(x=25,y=310)

variable3=StringVar()

search_button=customtkinter.CTkButton(app,font=font2,text_color='#fff',bg_color='#292933',text='Search',fg_color='#1345F9',hover_color='#0029BE',cursor='hand2',corner_radius=5,width=100,command=search_course)
search_button.place(x=420,y=312)

id_label=customtkinter.CTkLabel(frame2,font=font2,text='module ID:',text_color='#fff',bg_color='#292933')
id_label.place(x=50,y=15)

name_label=customtkinter.CTkLabel(frame2,font=font2,text='module name:',text_color='#fff',bg_color='#292933')
name_label.place(x=245,y=15)

duration_label=customtkinter.CTkLabel(frame2,font=font2,text='module duration:',text_color='#fff',bg_color='#292933')
duration_label.place(x=445,y=15)

format_label=customtkinter.CTkLabel(frame2,font=font2,text='module duration:',text_color='#fff',bg_color='#292933')
format_label.place(x=40,y=90)

language_label=customtkinter.CTkLabel(frame2,font=font2,text='module language:',text_color='#fff',bg_color='#292933')
language_label.place(x=245,y=90)

price_label=customtkinter.CTkLabel(frame2,font=font2,text='module price:',text_color='#fff',bg_color='#292933')
price_label.place(x=445,y=90)


ids_options=customtkinter.CTkComboBox(app,font=font2,text_color='#000',fg_color='#fff',dropdown_hover_color='#B2016C',button_color='#B2016C',button_hover_color='#B2016C',border_color='#B2016C',width=150,variable=variable3,state='readonly')
ids_options.set('Select')
ids_options.place(x=250,y=312)

#labels for inserting the Result

id_result_label=customtkinter.CTkLabel(frame2,font=font2,text='',text_color='#fff',bg_color='#292933')
id_result_label.place(x=50,y=45)

name_result_label=customtkinter.CTkLabel(frame2,font=font2,text='',text_color='#fff',bg_color='#292933')
name_result_label.place(x=245,y=45)

duration_result_label=customtkinter.CTkLabel(frame2,font=font2,text='',text_color='#fff',bg_color='#292933')
duration_result_label.place(x=445,y=45)

format_result_label=customtkinter.CTkLabel(frame2,font=font2,text='',text_color='#fff',bg_color='#292933')
format_result_label.place(x=40,y=120)

language_result_label=customtkinter.CTkLabel(frame2,font=font2,text='',text_color='#fff',bg_color='#292933')
language_result_label.place(x=245,y=120)

price_result_label=customtkinter.CTkLabel(frame2,font=font2,text='',text_color='#fff',bg_color='#292933')
price_result_label.place(x=445,y=120)


insert_ids_options()

app.mainloop()







